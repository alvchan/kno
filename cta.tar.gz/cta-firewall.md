# Firewall [cta-firewall.md]

A network device that filters traffic out by port number or application.
Firewalls also provide a range of other security features at endpoints, such as
traffic encryption and proxying.

They are often considered OSI layer 4 (TCP/UDP) devices and layer 7 devices if
they are aware of application layer traffic. Some firewalls are also considered
layer 3 devices because they make forwarding decisions based on IP addresses,
just like how routers do.

---

## Akin
[Router](cta-router.md)
