# Access Point [cta-accessp.md]

Network device to provide wireless connectivity for a local network from a wired
network. It simply extends or "bridges" a wired network onto the wireless
network at that point. Forwarding is reliant on checking MAC addresses to
determine if a connection is on the wireless or wired network, and to send data
accordingly.

---

## Akin
[Router](cta-router.md)
