# Power over Ethernet [cta-poweth.md]

A feature directly 
