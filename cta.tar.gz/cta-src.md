# Sources [cta-src.md]

1. CompTIA 220-1101 A+ Training Course by Professor Messer

---
