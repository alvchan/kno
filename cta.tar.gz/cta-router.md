# Router [cta-router.md]

Network devices that direct traffic between subnets by forwarding based on its
IP address. They can be used to connect a large range of incoming and outgoing
network types.

---

## Akin
[Switch](cta-switch.md)
